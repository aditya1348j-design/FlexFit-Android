package com.flexfit.home

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.delay

private val Bg = Color(0xFF101714)
private val Surface = Color(0xFF1B2822)
private val Green = Color(0xFF35C58A)
private val Muted = Color(0xFFAABBB2)

data class Exercise(val name: String, val category: String, val equipment: String, val icon: String, val how: String, val reps: String)

private val exercises = listOf(
    Exercise("Band Bicep Curl", "Upper Body", "Resistance Band", "💪", "Stand on the middle of the band. Hold its ends with palms forward. Bend your elbows to lift, then lower slowly.", "2 sets · 8–12 reps"),
    Exercise("Resistance Band Row", "Upper Body", "Resistance Tube", "🚣", "Secure the tube safely. Pull elbows back toward your sides, keep your back neutral, then release slowly.", "2 sets · 8–12 reps"),
    Exercise("Wall Push-up", "Upper Body", "No equipment", "🧍", "Face a wall with hands at chest height. Bend elbows to move closer, then gently push away.", "2 sets · 8–10 reps"),
    Exercise("Shoulder Press", "Upper Body", "Light Dumbbells", "🏋️", "Hold light dumbbells near shoulders. Press upward within a comfortable range and lower slowly.", "2 sets · 8–10 reps"),
    Exercise("Bodyweight Squat", "Lower Body", "No equipment", "🦵", "Stand comfortably. Bend hips and knees as if sitting on a chair, keep heels grounded, then stand.", "2 sets · 8–12 reps"),
    Exercise("Glute Bridge", "Lower Body", "No equipment", "🌉", "Lie on your back with knees bent. Lift hips comfortably, then lower with control.", "2 sets · 10 reps"),
    Exercise("Bird Dog", "Core", "No equipment", "🐦", "On hands and knees, extend one arm and opposite leg without twisting. Return and switch sides.", "2 sets · 6 each side"),
    Exercise("Dead Bug", "Core", "No equipment", "🧘", "Lie on your back with knees bent. Slowly extend opposite arm and leg within a comfortable range.", "2 sets · 6 each side"),
    Exercise("Arm Circles", "Mobility", "No equipment", "⭕", "Stand tall and make small controlled circles with your arms. Reverse direction.", "20 sec each way"),
    Exercise("March in Place", "Mobility", "No equipment", "🚶", "March gently on the spot, moving opposite arm and leg. Start slowly.", "1–2 minutes")
)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { FlexFitApp() }
    }
}

@Composable
fun FlexFitApp() {
    var page by remember { mutableStateOf("Home") }
    var selected by remember { mutableStateOf<Exercise?>(null) }
    var completed by remember { mutableIntStateOf(0) }
    var doneExercises by remember { mutableIntStateOf(0) }
    var session by remember { mutableStateOf<List<Exercise>>(emptyList()) }
    var index by remember { mutableIntStateOf(0) }
    var seconds by remember { mutableIntStateOf(30) }
    var running by remember { mutableStateOf(false) }
    var query by remember { mutableStateOf("") }

    LaunchedEffect(running, seconds, page) {
        while (running && page == "Session" && seconds > 0) {
            delay(1000)
            seconds--
        }
        if (seconds == 0) running = false
    }

    MaterialTheme(colorScheme = darkColorScheme(
        background = Bg, surface = Surface, primary = Green, onPrimary = Bg,
        onBackground = Color.White, onSurface = Color.White, secondary = Green
    )) {
        Scaffold(containerColor = Bg, bottomBar = {
            NavigationBar(containerColor = Surface, contentColor = Green) {
                listOf("Home", "Workouts", "Exercises", "Progress").forEach { item ->
                    NavigationBarItem(
                        selected = page == item,
                        onClick = { running = false; page = item; selected = null },
                        icon = {
                            Icon(when(item) {
                                "Home" -> Icons.Default.Home
                                "Workouts" -> Icons.Default.FitnessCenter
                                "Exercises" -> Icons.Default.MenuBook
                                else -> Icons.Default.Insights
                            }, contentDescription = item)
                        },
                        label = { Text(item, fontSize = 10.sp) },
                        colors = NavigationBarItemDefaults.colors(selectedIconColor = Green, selectedTextColor = Green, indicatorColor = Bg, unselectedIconColor = Muted, unselectedTextColor = Muted)
                    )
                }
            }
        }) { padding ->
            Column(Modifier.fillMaxSize().padding(padding).padding(horizontal = 18.dp)) {
                when (page) {
                    "Home" -> HomePage(
                        onStart = { type ->
                            session = when(type) {
                                "Upper Body" -> exercises.filter { it.category == "Upper Body" }
                                "Lower Body" -> exercises.filter { it.category == "Lower Body" }
                                "Mobility" -> exercises.filter { it.category == "Mobility" }
                                else -> listOf(exercises[0], exercises[1], exercises[4], exercises[5], exercises[6])
                            }
                            index = 0; seconds = 30; running = false; page = "Session"
                        },
                        onBrowse = { page = "Exercises" }
                    )
                    "Workouts" -> WorkoutsPage { type ->
                        session = when(type) {
                            "Upper Body" -> exercises.filter { it.category == "Upper Body" }
                            "Lower Body" -> exercises.filter { it.category == "Lower Body" }
                            "Mobility" -> exercises.filter { it.category == "Mobility" }
                            else -> listOf(exercises[0], exercises[1], exercises[4], exercises[5], exercises[6])
                        }
                        index = 0; seconds = 30; running = false; page = "Session"
                    }
                    "Exercises" -> {
                        Text("Exercise Library", fontSize = 25.sp, fontWeight = FontWeight.Bold, modifier = Modifier.padding(top = 20.dp, bottom = 12.dp))
                        OutlinedTextField(query, { query = it }, Modifier.fillMaxWidth(), placeholder = { Text("Search exercises...") }, singleLine = true)
                        Spacer(Modifier.height(10.dp))
                        LazyColumn(verticalArrangement = Arrangement.spacedBy(9.dp)) {
                            items(exercises.filter { it.name.contains(query, true) || it.category.contains(query, true) || it.equipment.contains(query, true) }) { ex ->
                                ExerciseCard(ex) { selected = ex }
                            }
                        }
                    }
                    "Progress" -> ProgressPage(completed, doneExercises) { completed = 0; doneExercises = 0 }
                    "Detail" -> selected?.let { ExerciseDetail(it) { page = "Exercises" } }
                    "Session" -> {
                        if (session.isNotEmpty() && index < session.size) {
                            SessionPage(session[index], index + 1, session.size, seconds, running,
                                onToggle = { running = !running },
                                onNext = {
                                    running = false
                                    if (index + 1 < session.size) { index++; seconds = 30 }
                                    else { completed++; doneExercises += session.size; page = "Progress" }
                                },
                                onExit = { running = false; page = "Workouts" }
                            )
                        }
                    }
                }
                if (page == "Exercises" && selected != null) {
                    // Detail is opened through the selected exercise card overlay below.
                }
            }
        }
        if (selected != null && page == "Exercises") {
            AlertDialog(
                onDismissRequest = { selected = null },
                containerColor = Surface,
                title = { Text("${selected!!.icon}  ${selected!!.name}") },
                text = { Column { Text(selected!!.equipment, color = Green); Spacer(Modifier.height(8.dp)); Text(selected!!.how); Spacer(Modifier.height(8.dp)); Text(selected!!.reps, color = Muted) } },
                confirmButton = { TextButton(onClick = { selected = null }) { Text("Close", color = Green) } }
            )
        }
    }
}

@Composable
fun HomePage(onStart: (String) -> Unit, onBrowse: () -> Unit) {
    LazyColumn(contentPadding = PaddingValues(vertical = 18.dp), verticalArrangement = Arrangement.spacedBy(16.dp)) {
        item {
            Column(Modifier.fillMaxWidth().background(Color(0xFF174B39), RoundedCornerShape(22.dp)).padding(20.dp)) {
                Text("FLEXFIT  ·  HOME FITNESS", color = Color(0xFFBCEBD6), fontSize = 12.sp, fontWeight = FontWeight.Bold)
                Spacer(Modifier.height(18.dp))
                Text("Your workout.\\nYour progress.", color = Color.White, fontSize = 29.sp, fontWeight = FontWeight.Bold, lineHeight = 34.sp)
                Text("अपनी गति से मजबूत बनें · Train at your pace", color = Color(0xFFD2F1E2), fontSize = 13.sp, modifier = Modifier.padding(top = 8.dp))
                Spacer(Modifier.height(18.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    StatPill("Today", "20–30 min")
                    StatPill("Level", "Beginner")
                }
            }
        }
        item { Text("आज का वर्कआउट · Today's Workout", fontSize = 20.sp, fontWeight = FontWeight.Bold) }
        item {
            Column(Modifier.fillMaxWidth().background(Surface, RoundedCornerShape(18.dp)).padding(16.dp)) {
                Text("Full Body Strength", fontSize = 18.sp, fontWeight = FontWeight.Bold)
                Text("Band + Tube + Light Dumbbells", color = Muted, fontSize = 13.sp)
                Text("5 exercises  ·  Rest included", color = Green, fontSize = 12.sp, modifier = Modifier.padding(top = 9.dp))
                Button(onClick = { onStart("Full Body") }, Modifier.fillMaxWidth().padding(top = 12.dp), colors = ButtonDefaults.buttonColors(containerColor = Green)) { Text("Start Workout  →") }
            }
        }
        item { Text("Choose your training", fontSize = 20.sp, fontWeight = FontWeight.Bold) }
        item {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    CategoryTile("💪", "Upper Body", Modifier.weight(1f)) { onStart("Upper Body") }
                    CategoryTile("🦵", "Lower Body", Modifier.weight(1f)) { onStart("Lower Body") }
                }
                Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    CategoryTile("🧘", "Core", Modifier.weight(1f)) { onStart("Full Body") }
                    CategoryTile("🤸", "Mobility", Modifier.weight(1f)) { onStart("Mobility") }
                }
            }
        }
        item {
            Text("Tip: Warm up first. Use light resistance and stop if you feel pain or dizziness. Recovery days are important.", color = Muted, fontSize = 12.sp)
        }
    }
}

@Composable fun StatPill(label: String, value: String) {
    Column(Modifier.background(Color(0xFF2C634F), RoundedCornerShape(12.dp)).padding(12.dp).widthIn(min = 95.dp)) {
        Text(label, color = Color(0xFFBCEBD6), fontSize = 11.sp)
        Text(value, color = Color.White, fontWeight = FontWeight.Bold, fontSize = 17.sp)
    }
}
@Composable fun CategoryTile(icon: String, label: String, modifier: Modifier, onClick: () -> Unit) {
    Column(modifier.background(Surface, RoundedCornerShape(16.dp)).clickable { onClick() }.padding(14.dp)) {
        Text(icon, fontSize = 27.sp); Text(label, fontWeight = FontWeight.Bold); Text("Explore →", color = Muted, fontSize = 11.sp)
    }
}
@Composable fun ExerciseCard(ex: Exercise, onClick: () -> Unit) {
    Row(Modifier.fillMaxWidth().background(Surface, RoundedCornerShape(15.dp)).clickable { onClick() }.padding(13.dp), verticalAlignment = Alignment.CenterVertically) {
        Text(ex.icon, fontSize = 29.sp, modifier = Modifier.padding(end = 13.dp))
        Column(Modifier.weight(1f)) {
            Text(ex.name, fontWeight = FontWeight.Bold)
            Text("${ex.category} · ${ex.equipment}", color = Muted, fontSize = 11.sp)
        }
        Icon(Icons.Default.ChevronRight, contentDescription = null, tint = Green)
    }
}
@Composable fun WorkoutsPage(onStart: (String) -> Unit) {
    LazyColumn(contentPadding = PaddingValues(vertical = 20.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        item { Text("Workout Plans", fontSize = 25.sp, fontWeight = FontWeight.Bold); Text("छोटे और आसान सेशन चुनें · Choose a session", color = Muted) }
        items(listOf("Full Body", "Upper Body", "Lower Body", "Mobility")) { name ->
            Column(Modifier.fillMaxWidth().background(Surface, RoundedCornerShape(16.dp)).padding(15.dp)) {
                Text(name, fontSize = 18.sp, fontWeight = FontWeight.Bold)
                Text(if(name=="Mobility") "10 minutes · No equipment" else "20–25 minutes · Beginner friendly", color = Muted, fontSize = 12.sp)
                Button(onClick = { onStart(name) }, Modifier.fillMaxWidth().padding(top = 8.dp), colors = ButtonDefaults.buttonColors(containerColor = Green)) { Text("Start") }
            }
        }
    }
}
@Composable fun ProgressPage(completed: Int, done: Int, onReset: () -> Unit) {
    Column(Modifier.fillMaxSize().padding(top = 22.dp)) {
        Text("Your Progress", fontSize = 25.sp, fontWeight = FontWeight.Bold)
        Text("तुम्हारी मेहनत का रिकॉर्ड", color = Muted)
        Row(horizontalArrangement = Arrangement.spacedBy(10.dp), modifier = Modifier.padding(top = 18.dp)) {
            ProgressCard("Completed Sessions", completed.toString(), Modifier.weight(1f))
            ProgressCard("Exercises Done", done.toString(), Modifier.weight(1f))
        }
        Spacer(Modifier.height(18.dp))
        Text("Consistency matters more than intensity. Take rest days and focus on comfortable technique.", color = Muted)
        OutlinedButton(onClick = onReset, Modifier.fillMaxWidth().padding(top = 18.dp)) { Text("Reset Progress", color = Green) }
    }
}
@Composable fun ProgressCard(label: String, value: String, modifier: Modifier) {
    Column(modifier.background(Surface, RoundedCornerShape(15.dp)).padding(14.dp)) { Text(label, color = Muted, fontSize = 12.sp); Text(value, fontSize = 30.sp, fontWeight = FontWeight.Bold, color = Green) }
}
@Composable fun ExerciseDetail(ex: Exercise, onBack: () -> Unit) {
    Column(Modifier.fillMaxSize().padding(top = 20.dp)) {
        TextButton(onClick = onBack) { Text("← Back", color = Green) }
        Text(ex.icon, fontSize = 52.sp)
        Text(ex.name, fontSize = 24.sp, fontWeight = FontWeight.Bold)
        Text(ex.equipment, color = Green)
        Spacer(Modifier.height(15.dp))
        Text("How to do it", fontWeight = FontWeight.Bold)
        Text(ex.how, color = Muted, modifier = Modifier.padding(top = 6.dp))
        Spacer(Modifier.height(15.dp))
        Text("Suggested practice", fontWeight = FontWeight.Bold)
        Text(ex.reps, color = Muted)
    }
}
@Composable fun SessionPage(ex: Exercise, number: Int, total: Int, seconds: Int, running: Boolean, onToggle: () -> Unit, onNext: () -> Unit, onExit: () -> Unit) {
    Column(Modifier.fillMaxSize().padding(top = 18.dp), horizontalAlignment = Alignment.CenterHorizontally) {
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.Start) { TextButton(onClick = onExit) { Text("← Exit workout", color = Green) } }
        Spacer(Modifier.height(25.dp))
        Text("EXERCISE $number OF $total", color = Muted, fontSize = 12.sp)
        Text(ex.icon, fontSize = 58.sp, modifier = Modifier.padding(18.dp))
        Text(ex.name, fontSize = 23.sp, fontWeight = FontWeight.Bold)
        Text(ex.how, color = Muted, fontSize = 14.sp, modifier = Modifier.padding(14.dp))
        Text(String.format("%02d:%02d", seconds / 60, seconds % 60), fontSize = 54.sp, fontWeight = FontWeight.Bold, color = Green, modifier = Modifier.padding(22.dp))
        Text(ex.reps, color = Muted)
        Button(onClick = onToggle, Modifier.fillMaxWidth().padding(top = 25.dp), colors = ButtonDefaults.buttonColors(containerColor = Green)) { Text(if(running) "Pause Timer" else "Start Timer") }
        OutlinedButton(onClick = onNext, Modifier.fillMaxWidth().padding(top = 10.dp)) { Text(if(number == total) "Finish Workout" else "Next Exercise →", color = Green) }
    }
}

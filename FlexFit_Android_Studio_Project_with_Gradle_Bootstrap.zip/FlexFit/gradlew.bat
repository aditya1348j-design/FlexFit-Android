@echo off
setlocal
set "GRADLE_VERSION=8.9"
set "GRADLE_HOME=%USERPROFILE%\.gradle\flexfit-bootstrap\gradle-%GRADLE_VERSION%"
if exist "%GRADLE_HOME%\bin\gradle.bat" goto run_gradle

set "ZIP_FILE=%TEMP%\gradle-%GRADLE_VERSION%-bin.zip"
set "GRADLE_URL=https://services.gradle.org/distributions/gradle-%GRADLE_VERSION%-bin.zip"
set "EXPECTED_SHA256=d725d707bfabd4dfdc958c624003b3c80accc03f7037b5122c4b1d0ef15cecab"

powershell -NoProfile -ExecutionPolicy Bypass -Command "$ErrorActionPreference='Stop'; Invoke-WebRequest -Uri '%GRADLE_URL%' -OutFile '%ZIP_FILE%'; $actual=(Get-FileHash -Algorithm SHA256 '%ZIP_FILE%').Hash.ToLowerInvariant(); if ($actual -ne '%EXPECTED_SHA256%') { throw 'Gradle 8.9 SHA-256 mismatch' }; $base=Split-Path '%GRADLE_HOME%'; New-Item -ItemType Directory -Force -Path $base | Out-Null; Expand-Archive -Force '%ZIP_FILE%' $base; Remove-Item -Force '%ZIP_FILE%'"
if errorlevel 1 exit /b 1

:run_gradle
call "%GRADLE_HOME%\bin\gradle.bat" %*
exit /b %ERRORLEVEL%

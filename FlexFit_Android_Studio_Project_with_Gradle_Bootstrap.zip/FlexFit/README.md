# FlexFit Android project

A native Android Studio starter project for FlexFit, with Hindi + English UI and a Dark + Green theme.

## Build an APK
1. Install Android Studio (recent stable version) and Android SDK Platform 35.
2. Open this `FlexFit` folder in Android Studio.
3. Allow Gradle sync to finish.
4. Select **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
5. Android Studio will show the APK location, usually `app/build/outputs/apk/debug/app-debug.apk`.

For a Play Store release, create a signed Android App Bundle (AAB) via **Build > Generate Signed Bundle / APK** and follow Google Play Console's current requirements.

## Included
- Native Kotlin + Jetpack Compose Android app
- Hindi + English labels
- Dark + Green theme
- Workout plans, exercise library, search, instructions, timer and session counters
- Offline starter exercise data

## Notes
This is a source project, not a precompiled APK. Exercise illustrations are emoji placeholders; add verified demonstration images/videos and test the app on real devices before publishing. Progress currently lives in app memory and resets when the app process is recreated. A production release should add persistent storage, accessibility checks, privacy policy, app icon, screenshots, and signed release testing.

## GitHub Actions build note

This ZIP includes a `gradlew` bootstrap script for Linux CI and a matching `gradlew.bat` helper for Windows. The script downloads the official Gradle 8.9 binary distribution and checks its published SHA-256 before running the build. It is a lightweight bootstrap launcher, not the standard JAR-based Gradle Wrapper; the workflow in this repository only needs the executable `gradlew` script to be present and run. The Gradle version is set to 8.9 to match Android Gradle Plugin 8.7.3.
